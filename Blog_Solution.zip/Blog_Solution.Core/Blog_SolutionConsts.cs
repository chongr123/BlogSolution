﻿namespace Blog_Solution
{
    public class Blog_SolutionConsts
    {
        public const string LocalizationSourceName = "Blog_Solution";
    }
}