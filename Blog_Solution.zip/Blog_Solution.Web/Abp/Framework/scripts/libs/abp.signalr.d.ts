﻿declare namespace abp {

    namespace signalr {

        let autoConnect: boolean;

        function connect();

        namespace hubs {

            let common: any;

        }

    }

}